while True:
      print("\n============== Count Digits and Letters in a String ==============\n")
      string=input("Enter string: ")
      count1=0
      count2=0
      for i in string:
            if(i.isdigit()):
                  count1=count1+1
            count2=count2+1
      print("The number of digits is:")
      print(count1)
      print("The number of characters is:")
      print(count2)

      opt = input("\nDo you want to try again?(yes/no): ")
           
      if opt.lower() == 'yes':
            ret=False
      elif opt.lower() == 'no':
            ret=True
            print("Exiting program....")
      else:
            print("Please enter yes/no:")
            break
 
      if ret == False:
            continue
